
<div class="row d-grid gap-3">
    <div id="livematchlist">
    </div>

</div>

<script type="text/javascript">
    var $ = jQuery;
    var ajaxurl = "<?php echo admin_url('admin-ajax.php') ?>";
    $(document).ready(function() {
        live_match_list();

    })
</script>




